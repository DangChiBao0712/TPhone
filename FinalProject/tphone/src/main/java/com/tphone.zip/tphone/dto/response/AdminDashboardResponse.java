package com.tphone.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
public class AdminDashboardResponse {

    private Long totalUsers;
    private Long totalProducts;
    private Long totalOrders;
    private Long totalPendingOrders;

    private BigDecimal totalRevenue;
    private BigDecimal todayRevenue;

}