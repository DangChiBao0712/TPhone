package com.tphone.repository;

import com.tphone.entity.Account;
import com.tphone.enums.AccountProvider;
import com.tphone.enums.AccountStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface AccountRepository extends JpaRepository<Account, Long> {

    Optional<Account> findByEmail(String email);

    Optional<Account> findByPhone(String phone);

    boolean existsByEmail(String email);

    boolean existsByPhone(String phone);

    List<Account> findAllByStatus(AccountStatus status);

    List<Account> findAllByProvider(AccountProvider provider);

    Optional<Account> findByEmailAndDeletedAtIsNull(String email);

    boolean existsByEmailAndDeletedAtIsNull(String email);

    List<Account> findAllByDeletedAtIsNull();
}