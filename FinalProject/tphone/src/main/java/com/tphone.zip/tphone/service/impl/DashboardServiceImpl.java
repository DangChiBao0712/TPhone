package com.tphone.service.impl;

import com.tphone.dto.response.AdminDashboardResponse;
import com.tphone.enums.OrderStatus;
import com.tphone.enums.PaymentStatus;
import com.tphone.repository.AccountRepository;
import com.tphone.repository.OrderRepository;
import com.tphone.repository.ProductRepository;
import com.tphone.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {

    private final AccountRepository accountRepository;
    private final ProductRepository productRepository;
    private final OrderRepository orderRepository;

    @Override
    public AdminDashboardResponse getDashboard() {

        Long totalUsers = accountRepository.count();

        Long totalProducts = productRepository.count();

        Long totalOrders = orderRepository.count();

        Long totalPendingOrders = orderRepository.countByOrderStatus(OrderStatus.PENDING);

        BigDecimal totalRevenue = orderRepository
                .findAllByPaymentStatus(PaymentStatus.SUCCESS)
                .stream()
                .map(order -> order.getTotalAmount() != null ? order.getTotalAmount() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        LocalDate today = LocalDate.now();

        BigDecimal todayRevenue = orderRepository
                .findAllByPaymentStatus(PaymentStatus.SUCCESS)
                .stream()
                .filter(order -> order.getPlacedAt() != null)
                .filter(order -> order.getPlacedAt().toLocalDate().equals(today))
                .map(order -> order.getTotalAmount() != null ? order.getTotalAmount() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return new AdminDashboardResponse(
                totalUsers,
                totalProducts,
                totalOrders,
                totalPendingOrders,
                totalRevenue,
                todayRevenue
        );
    }
}