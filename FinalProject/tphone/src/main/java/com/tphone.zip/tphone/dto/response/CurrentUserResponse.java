package com.tphone.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
public class CurrentUserResponse {
    private Long id;
    private String email;
    private String fullName;
    private List<String> roles;
}