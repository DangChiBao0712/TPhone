package com.tphone.service;

import com.tphone.dto.response.AdminDashboardResponse;

public interface DashboardService {
    AdminDashboardResponse getDashboard();
}